import { vi } from 'vitest';
vi.setSystemTime(new Date('2026-10-15T12:00:00Z'));
