import { it, expect, vi, beforeEach } from 'vitest';
import { readJsonLimited } from '../../base44/shared/requestSafety.ts';
const fixture = vi.hoisted(() => ({ client: null }));
vi.mock('npm:@base44/sdk@0.8.53', () => ({ createClientFromRequest: () => fixture.client }));
import feedback from '../../base44/functions/submitFeedback/entry.ts';
import contribute from '../../base44/functions/logGoalContribution/entry.ts';
beforeEach(() => {
  fixture.client = {
    auth: { me: async () => ({ id: 'audit-local-user' }) },
    entities: {
      Feedback: { upsert: vi.fn(async () => []) },
      Goal: { filter: vi.fn(async () => ({ items: [{ id: 'goal-local', created_by_id: 'audit-local-user', demo_profile: '' }], has_more: false })) },
      GoalContribution: { filter: vi.fn(async () => ({ items: [], has_more: false })), upsert: vi.fn(async () => []) },
    },
  };
});
const req = body => new Request('https://fixture.test', { method: 'POST', body: JSON.stringify(body) });
it('AD-01 feedback rejects 100KB ignored padding before persistence', async () => {
  const response = await feedback(req({ rating: 5, message: 'Synthetic test feedback', consent: true, request_id: 'audit-local-request-0001', padding: 'x'.repeat(100000) }));
  console.log('AD-01 observed', response.status, 'writes', fixture.client.entities.Feedback.upsert.mock.calls.length);
  expect(response.status).toBe(413);
  expect(fixture.client.entities.Feedback.upsert).not.toHaveBeenCalled();
});
it('AD-02 contribution rejects 100KB ignored padding before persistence', async () => {
  const response = await contribute(req({ goal_id: 'goal-local', amount: 10, request_id: 'audit-local-request-0002', padding: 'x'.repeat(100000) }));
  console.log('AD-02 observed', response.status, 'writes', fixture.client.entities.GoalContribution.upsert.mock.calls.length);
  expect(response.status).toBe(413);
  expect(fixture.client.entities.GoalContribution.upsert).not.toHaveBeenCalled();
});
it('AD-03 JSON parser accepts exactly its byte limit and rejects one byte above', async () => {
  const body = JSON.stringify({ x: 'a'.repeat(12) });
  expect(new TextEncoder().encode(body).length).toBe(20);
  expect(await readJsonLimited(new Request('https://fixture.test', { method: 'POST', body }), 20)).toEqual({ x: 'a'.repeat(12) });
  await expect(readJsonLimited(new Request('https://fixture.test', { method: 'POST', body: body + ' ' }), 20)).rejects.toMatchObject({ status: 413 });
});
it('AD-04 JSON parser rejects malformed UTF-8 rather than replacing bytes', async () => {
  const bytes = new Uint8Array([123,34,120,34,58,34,255,34,125]);
  await expect(readJsonLimited(new Request('https://fixture.test', { method: 'POST', body: bytes }))).rejects.toMatchObject({ status: 400 });
});
